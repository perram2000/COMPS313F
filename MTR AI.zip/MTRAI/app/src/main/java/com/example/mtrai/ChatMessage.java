package com.example.mtrai;

public class ChatMessage {
    private String message;
    private boolean isUser; // 标识消息是否来自用户

    public ChatMessage(String message, boolean isUser) {
        this.message = message;
        this.isUser = isUser;
    }

    public String getMessage() {
        return message;
    }

    public boolean isUser() {
        return isUser;
    }
}