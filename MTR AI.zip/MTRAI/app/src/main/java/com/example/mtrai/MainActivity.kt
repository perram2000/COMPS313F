package com.example.mtrai

import android.os.Bundle
import android.util.Log
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.*
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private lateinit var chatRecyclerView: RecyclerView
    private lateinit var chatAdapter: ChatAdapter
    private val chatMessages: MutableList<ChatMessage> = mutableListOf()
    private lateinit var questionListView: ListView
    private lateinit var requestQueue: RequestQueue // Volley 请求队列

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // 初始化 RecyclerView
        chatRecyclerView = findViewById(R.id.chatRecyclerView)
        chatRecyclerView.layoutManager = LinearLayoutManager(this)

        // 初始化适配器
        chatAdapter = ChatAdapter(chatMessages)
        chatRecyclerView.adapter = chatAdapter

        // 初始化 ListView（预设问题）
        questionListView = findViewById(R.id.questionListView)
        val questions = arrayOf(
            "What's near Ho Man Tin MTR Station?",
            "What's near Central MTR Station?",
            "What's near Austin MTR Station?"
        )
        questionListView.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, questions)

        // 处理点击事件
        questionListView.setOnItemClickListener { _, _, i, _ ->
            val question = questions[i]
            chatMessages.add(ChatMessage(question, true)) // 用户输入
            chatAdapter.notifyDataSetChanged()
            sendMessageToGPT(question) // 调用 DeepSeek API
        }

        // 初始化 Volley 请求队列
        requestQueue = Volley.newRequestQueue(this)
    }

    // **✅ 这里是 DeepSeek API 调用逻辑**
    private fun sendMessageToGPT(question: String) {
        Log.d("API_REQUEST", "Sending question: $question")
        val apiKey = "sk-4fdef9f34a4a497aa43b5d33a8db0387" // ❗ 替换为你的 DeepSeek API Key
        val url = "https://api.deepseek.com/v1/chat/completions" // ✅ DeepSeek API 地址

        // 构建请求 JSON
        val jsonBody = JSONObject()
        try {
            jsonBody.put("model", "deepseek-chat") // ✅ 使用 DeepSeek 模型
            val messagesArray = JSONArray()
            messagesArray.put(JSONObject().put("role", "user").put("content", question))
            jsonBody.put("messages", messagesArray)
        } catch (e: JSONException) {
            e.printStackTrace()
        }

        // 发送请求
        val request = object : JsonObjectRequest(
            Request.Method.POST, url, jsonBody,
            Response.Listener { response ->
                Log.d("API_RESPONSE", "Full Response: $response")  // ✅ 确保 API 响应被打印

                try {
                    val choicesArray = response.optJSONArray("choices")
                    if (choicesArray != null && choicesArray.length() > 0) {
                        val messageObj = choicesArray.getJSONObject(0).optJSONObject("message")
                        val reply = messageObj?.optString("content") ?: "No response"

                        // ✅ 在主线程更新 UI
                        runOnUiThread {
                            chatMessages.add(ChatMessage(reply, false))
                            chatAdapter.notifyDataSetChanged()
                            chatRecyclerView.scrollToPosition(chatMessages.size - 1)
                        }
                    } else {
                        Log.e("API_ERROR", "No choices found in response")
                    }
                } catch (e: JSONException) {
                    Log.e("API_ERROR", "JSON Parsing Error: ${e.message}")
                }
            },
            Response.ErrorListener { error ->
                Log.e("API_ERROR", "Volley Error: ${error.message}")
                error.printStackTrace()
            }) {
            override fun getHeaders(): Map<String, String> {
                val headers = HashMap<String, String>()
                headers["Authorization"] = "Bearer $apiKey"
                headers["Content-Type"] = "application/json"
                return headers
            }
        }

        // ✅ 增加超时时间（15 秒）
        request.retryPolicy = DefaultRetryPolicy(
            15000, // 超时时间（15 秒）
            DefaultRetryPolicy.DEFAULT_MAX_RETRIES, // 默认重试次数
            DefaultRetryPolicy.DEFAULT_BACKOFF_MULT // 退避系数
        )

        // ✅ 添加请求到队列
        requestQueue.add(request)
    }
}